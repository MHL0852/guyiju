//固宜居美缝
var productData = [
  [
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail2.html',
      url: "./image/product2.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail2.html',
      url: "./image/product2.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail2.html',
      url: "./image/product2.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
  ],
  [
    {
      link: './detail2.html',
      url: "./image/product2.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detai2.html',
      url: "./image/product2.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detai2.html',
      url: "./image/product2.png",
      text: '固宜居生态真瓷美缝'
    },
  ],
  [
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
  ],
  [
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
    {
      link: './detail.html',
      url: "./image/product1.png",
      text: '固宜居生态真瓷美缝'
    },
  ],
];
//首页
var homeData = {
  //轮播图
  "banner": [
    {
      "id": 1,
      "img": "./image/home_banner1.png",
      "link": "./products.html"
    },
    {
      "id": 2,
      "img": "./image/home_banner2.png",
      "link": "./products.html"
    }
  ],
  //以下是正文的数据，titleUrl是标题前面图标的路径，subTitle是副标题，分为普通颜色和着重色，content是具体的内容
  "part1": {
    "title": "明星产品",
    "titleUrl": "./image/home_icon1.png",
    "subTitle": {
      "normal": "固宜居美缝剂",
      "bold": "\"热销产品推荐\""
    },
    "content": [
      {
        "url": "./image/product1.png",
        "describe": "固宜居生态水瓷美缝1"
      },
      {
        "url": "./image/product2.png",
        "describe": "固宜居生态水瓷美缝2"
      },
      {
        "url": "./image/product1.png",
        "describe": "固宜居生态水瓷美缝3"
      }
    ]
  },
  "part2": {
    "title": "品牌故事",
    "titleUrl": "./image/home_icon1.png",
    "subTitle": {
      "normal": "固宜居美缝剂，\"安全环保，为健康而生\"",
      "bold": ""
    },
    "content": {
      "url": "./image/product1.png",
      "backgroundUrl": "./image/product_background.png",
      "title": "固宜居建材有限公司——中国美缝行业领跑者",
      "text": "文案参考 文案参考 文案参考 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代,文案参考 文案参考 文案参考固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代。文案参考 文案参考 文案参考固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代，文案参考 文案参考 文案参考固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代。 "
    }
  },
  "part3": {
    "title": "技术支持",
    "titleUrl": "./image/home_icon3.png",
    "subTitle": {
      "normal": "将环保做到更好",
      "bold": "这是固宜居做事的态度"
    },
    "content": {
      "url": "",
      "backgroundUrl": "./image/home_technology_background.png",
      "title": "雄厚的技术研发、生产销售、售后服务实力",
      "text": "国内首家通过3.15认证产品，通过ISO9001、14001等权威认证。采用优质进口环保材料，先进设备工艺精制而成，绿色环保更健康<br/>主推固宜居美缝剂产品，用更环保的产品呵护每一个家庭图片文字内容仅供参考    图片文字内容仅供参考     图片文字内容仅供参"
    }
  },
  "part4": {
    "title": "服务专区",
    "titleUrl": "./image/home_icon4.png",
    "subTitle": {
      "normal": "愿我的服务质量和你随时相伴",
      "bold": "为你，做得更好"
    },
    "backgroundUrl": "./image/home_service_background.png",
    "content": {
      "url": "",
      "backgroundUrl": "",
      "title": "一个电话，免费上门，10项免费服务;瓷砖美缝更容易",
      "text": "入驻佛山陶瓷总部基地，与各大品牌瓷砖厂家达成战略合作，提供一砖一 配色服务,匠心，让每一米缝隙更有温度，让每一个空间更有内涵，入驻佛山陶瓷总部基地，与各大品牌瓷砖厂家达成战略合作，提供一砖一 配色服务,匠心，让每一米缝隙更有温度，让每一个空间更有内涵，"
    }
  },
  "part5": {
    "title": "新闻资讯",
    "titleUrl": "./image/home_icon5.png",
    "subTitle": {
      "normal": "愿我的服务质量和你随时相伴",
      "bold": "为你，做得更好"
    },
    "content": [
      {
        "url": "./image/news1.png",
        "title": "固宜居美缝\"百日惠战\"启东会议，隆重召开！",
        "text": "惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理",
        "date": "12-08"
      },
      {
        "url": "./image/news2.png",
        "title": "固宜居美缝\"百日惠战\"启东会议，隆重召开了！",
        "text": "惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理",
        "date": "11-29"
      }
    ]
  }
};
//品牌故事
var storyData = {
  part0: {
    title: '固宜居建材有限公司——中国美缝行业领跑者',
    url: './image/story.png',
    imgDescribe: '配图示例-仅供参考',
    text: [
      ' 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。',
      '固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。'
    ]
  },
  part1: {
    content: [
      {
        title: '公司愿景',
        text: ['固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业', '固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业'
        
        ]
      },
      {
        title: '公司愿景 公司愿景', text: [
          '固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业。固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代化生产、营销、服务企业']
      }
    ]
  }
};
//精英团队
var teamData = {
  banner: './image/team_banner.png',
  content: [
    [
      {
        url: './image/team1.png',
        title: '图片仅供参考固宜居美缝团队0',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
      {
        url: './image/team2.png',
        title: '图片仅供参考固宜居美缝团队',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
      {
        url: './image/team3.png',
        title: '图片仅供参考固宜居美缝团队',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
    ],
    [
      {
        url: './image/team1.png',
        title: '图片仅供参考固宜居美缝团队1',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
      {
        url: './image/team2.png',
        title: '图片仅供参考固宜居美缝团队',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
    ],
    [
      {
        url: './image/team3.png',
        title: '图片仅供参考固宜居美缝团队2',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
      {
        url: './image/team2.png',
        title: '图片仅供参考固宜居美缝团队',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
      {
        url: './image/team1.png',
        title: '图片仅供参考固宜居美缝团队',
        text: '美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 美缝团队的整体简介 ......',
        link: ''
      },
    ]
  ]
};
//服务专区
var serviceData = {
  content: [
    [
      {
        question: '1、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '2、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '3、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '1、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '2、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '3、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '1、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '2、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '3、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
    ],
    [
      {
        question: '1、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '1、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      },
      {
        question: '1、我家的是无缝砖，那么还需要留缝吗？大概留多宽？',
        answer: '答：无缝砖也必须要留缝，留1mm的宽度。0.5毫米的深度。',
        date: '12-08',
        time: '11:36',
      }
    ]
  ]
};
//新闻资讯
var newsData = {
  content: [
    [
      {
        url: './image/news1.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
      {
        url: './image/news2.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
      {
        url: './image/news3.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
      {
        url: './image/news4.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
    ],
    [
      {
        url: './image/news5.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
      {
        url: './image/news4.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
      {
        url: './image/news3.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
      {
        url: './image/news2.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
      {
        url: './image/news1.png',
        title: '固宜居美缝“百日惠战”启东会议，隆重召开！',
        text: '惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理,惠万千家庭，铸铁军劲旅。固宜居美缝“百日惠战”启动会议今天正式开始。偌大的会场内聚集了固宜居美缝10位大区经理和50位区域经理',
        date: '12-08',
      },
    ],
  ]
};
//详情
var detailData1 = {
  part1: {
    title: '你还在为这些问题发愁吗？',
    subTitle: 'Are you still worried about these issues？',
    content: [
      {
        url: './image/detail/detail_part1_1.png',
        text: '卫生间受潮发霉，砖缝脏又黑',
      },
      {
        url: './image/detail/detail_part1_2.png',
        text: '厨房砖缝被菜汤油渍渗透，严重影响美观',
      },
      {
        url: './image/detail/detail_part1_3.png',
        text: '使用劣质美缝产品导致地砖空鼓',
      },
      {
        url: './image/detail/detail_part1_4.png',
        text: '瓷砖缝发霉发黑整体档次 直线下降',
      },
    ]
  },
  part2: {
    title: '固宜居水钻瓷/您身边的美缝专家',
    subTitle: 'The American sewing expert',
    content: {
      url: './image/detail_part2.png',
      text: [
        '文案参考 文案参考 文案参考 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代,文案参考 文案参考 文案参考 固宜居建材有限公司', '文案参考 文案参考 文案参考 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代,文案参考 文案参考 文案参考', '文案参考 文案参考 文案参考 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代,文案参考 文案参考 文案参考 固宜居建材有限公司固宜居建材有限公司'
      ],
      btn: '我要试试'
    }
  },
  part3: {
    title: '固宜居水钻瓷/固宜居水钻瓷特点',
    subTitle: 'porcelain characteristics',
    url: './image/detail_part3.png',
  },
  part4: {
    title: '固宜居水钻瓷/选择我们的理由',
    subTitle: 'Choose our reasons',
    describe: '在过去的5年里，固宜居建材产品以其安全、环保、施工便捷等优异特点在业界被广受赞誉。固宜居建材在同行内率先通过ISO9001认证,在过去的5年里，固宜居建材产品以其安全、环保、施工便捷等优异特点在业界被广受赞誉。固宜居建材在同行内率先通过ISO9001认证。',
    content: [
      {
        url: './image/detail/detail_part4_1.png'
      },
      {
        url: './image/detail/detail_part4_2.png'
      },
      {
        url: './image/detail/detail_part4_3.png'
      },
      {
        url: './image/detail/detail_part4_4.png'
      },
    ]
  },
  part5: {
    title: '固宜居水钻瓷/施工案例',
    subTitle: 'Construction case',
    content: [
      {
        url: './image/detail/detail_part5_1.png',
        text: '施工前'
      },
      {
        url: './image/detail/detail_part5_2.png',
        text: '施工后'
      },
      {
        url: './image/detail/detail_part5_3.png',
        text: '施工前'
      },
      {
        url: './image/detail/detail_part5_4.png',
        text: '施工后'
      },
      {
        url: './image/detail/detail_part5_5.png',
        text: ''
      },
      {
        url: './image/detail/detail_part5_6.png',
        text: ''
      },
      {
        url: './image/detail/detail_part5_7.png',
        text: ''
      },
      {
        url: './image/detail/detail_part5_8.png',
        text: ''
      },
    ]
  },
  part6: {
    title: '固宜居水钻瓷/其它产品推荐',
    subTitle: 'Other products recommended',
    content: [
      {
        url: './image/product1.png',
        text: '固宜居水钻瓷有优'
      },
      {
        url: './image/product2.png',
        text: '固宜居水钻瓷有优2'
      },
      {
        url: './image/detail_part6.png',
        text: '固宜居水钻瓷有优3'
      },
    
    ]
  },
  
};

var detailData2 = {
  part1: {
    title: '你还在为这些问题发愁吗？',
    subTitle: 'Are you still worried about these issues？',
    content: [
      {
        url: './image/detail_part1.png',
        text: '瓷砖缝发霉发黑整体档次 直线下降 ',
      },
      {
        url: './image/detail_part1.png',
        text: '瓷砖缝发霉发黑整体档次 直线下降 ',
      },
      {
        url: './image/detail_part1.png',
        text: '瓷砖缝发霉发黑整体档次 直线下降 ',
      },
      {
        url: './image/detail_part1.png',
        text: '瓷砖缝发霉发黑整体档次 直线下降 ',
      },
    ]
  },
  part2: {
    title: '固宜居水钻瓷/您身边的美缝专家',
    subTitle: 'The American sewing expert',
    content: {
      url: './image/detail_part2.png',
      text: [
        '文案参考 文案参考 文案参考 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代,文案参考 文案参考 文案参考 固宜居建材有限公司', '文案参考 文案参考 文案参考 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代,文案参考 文案参考 文案参考', '文案参考 文案参考 文案参考 固宜居建材有限公司成立于2011年，总部位于湖南长沙，是一家专业从事建筑建材化工领域的现代,文案参考 文案参考 文案参考 固宜居建材有限公司固宜居建材有限公司'
      ],
      btn: '我要试试'
    }
  },
  part3: {
    title: '固宜居水钻瓷/固宜居水钻瓷特点',
    subTitle: 'porcelain characteristics',
    url: './image/detail_part3.png',
  },
  part4: {
    title: '固宜居水钻瓷/选择我们的理由',
    subTitle: 'Choose our reasons',
    describe: '在过去的5年里，固宜居建材产品以其安全、环保、施工便捷等优异特点在业界被广受赞誉。固宜居建材在同行内率先通过ISO9001认证,在过去的5年里，固宜居建材产品以其安全、环保、施工便捷等优异特点在业界被广受赞誉。固宜居建材在同行内率先通过ISO9001认证。',
    content: [
      {
        url: './image/detail_part4.png'
      },
      {
        url: './image/detail_part4.png'
      },
      {
        url: './image/detail_part4.png'
      },
      {
        url: './image/detail_part4.png'
      },
    ]
  },
  part5: {
    title: '固宜居水钻瓷/施工案例',
    subTitle: 'Construction case',
    content: [
      {
        url: './image/detail_part5.png',
        text: '施工前'
      },
      {
        url: './image/detail_part5.png',
        text: '施工后'
      },
      {
        url: './image/detail_part5.png',
        text: '施工前'
      },
      {
        url: './image/detail_part5.png',
        text: '施工后'
      },
      {
        url: './image/detail_part5.png',
        text: ''
      },
      {
        url: './image/detail_part5.png',
        text: ''
      },
      {
        url: './image/detail_part5.png',
        text: ''
      },
      {
        url: './image/detail_part5.png',
        text: ''
      },
    ]
  },
  part6: {
    title: '固宜居水钻瓷/其它产品推荐',
    subTitle: 'Other products recommended',
    content: [
      {
        url: './image/detail_part6.png',
        text: '固宜居水钻瓷有优'
      },
      {
        url: './image/detail_part6.png',
        text: '固宜居水钻瓷有优2'
      },
      {
        url: './image/detail_part6.png',
        text: '固宜居水钻瓷有优3'
      },
    
    ]
  },
  
};